--- 
layout: page
title: The Lotus Sutra
type: page
status: publish
---
# The Lotus Sutra
(Also known as:)
<strong>Saddharma Pundarika Sutra</strong>
(Taisho Tripitaka 262)

<strong>Translated into Chinese during the Yil, Tson Dynasty by Kumarajiva</strong>

<strong>Translated into English by Burton Watson</strong>

<hr />
